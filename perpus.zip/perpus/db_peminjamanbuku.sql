/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 10.4.27-MariaDB : Database - db_peminjamanbuku
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_peminjamanbuku` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci */;

USE `db_peminjamanbuku`;

/*Table structure for table `anggota` */

DROP TABLE IF EXISTS `anggota`;

CREATE TABLE `anggota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nis` varchar(50) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `anggota` */

insert  into `anggota`(`id`,`user_id`,`nis`,`kelas`,`alamat`,`status`) values (4,5,'122132','XII','bekasi','aktif'),(3,4,'3254567','XII','jakarta','aktif'),(5,6,'98513','XII','bogor','aktif'),(6,7,'78254','XII','bandung','aktif'),(7,8,'07146','XII','jakarta','aktif');

/*Table structure for table `buku` */

DROP TABLE IF EXISTS `buku`;

CREATE TABLE `buku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_buku` varchar(50) DEFAULT NULL,
  `judul` varchar(50) DEFAULT NULL,
  `pengarang` varchar(50) DEFAULT NULL,
  `penerbit` varchar(50) DEFAULT NULL,
  `tahun` varchar(50) DEFAULT NULL,
  `stok` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `buku` */

insert  into `buku`(`id`,`kode_buku`,`judul`,`pengarang`,`penerbit`,`tahun`,`stok`) values (4,'09287','dongeng si kansil','pak kumis','susilo','2024','97'),(3,'32145','kisah mistis','pak wowo','susilo','2025','97'),(5,'143254','si malin kundang','mister adam','gatot','2015','94'),(8,'961395','masa smk','muqorobin','pak malik','2026','98'),(7,'815458','perjalanan soekarno','john','hermes','1999','98'),(9,'57825','siksa kubur','yusuf','pak malik','2000','97');

/*Table structure for table `peminjaman` */

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anggota_id` int(11) DEFAULT NULL,
  `tgl_pinjam` varchar(50) DEFAULT NULL,
  `tgl_kembali` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman` */

insert  into `peminjaman`(`id`,`anggota_id`,`tgl_pinjam`,`tgl_kembali`,`status`) values (1,2,'2026-03-13','2026-03-31','dipinjam'),(2,3,'2026-02-12','2026-03-30','dikembalikan'),(3,5,'2026-02-13','2026-03-20','dipinjam'),(4,3,'2026-03-01','2026-03-30','dikembalikan'),(5,3,'2026-02-20','2026-03-30','dipinjam'),(6,7,'2026-04-01','2026-04-28','dipinjam'),(7,6,'2026-02-25','2026-04-01','dipinjam'),(8,7,'2026-03-20','2026-04-04','dikembalikan'),(9,4,'2026-02-20','2026-03-15','dikembalikan'),(10,4,'2026-03-12','2026-04-01','dipinjam'),(11,4,'2026-01-10','2026-02-02','dikembalikan'),(12,4,'2026-01-11','2027-01-10','dipinjam'),(13,4,'2026-01-01','2026-02-10','dikembalikan'),(14,5,'2026-03-25','2026-04-10','dipinjam'),(15,5,'2026-04-20','2026-05-10','dipinjam'),(16,5,'2026-03-10','2026-03-30','dipinjam'),(17,5,'2026-04-03','2026-05-05','dipinjam'),(18,5,'2026-03-17','2026-04-18','dipinjam'),(19,5,'2026-03-25','2026-04-25','dipinjam'),(20,3,'2026-03-13','2026-04-14','dikembalikan');

/*Table structure for table `peminjaman_detail` */

DROP TABLE IF EXISTS `peminjaman_detail`;

CREATE TABLE `peminjaman_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(11) DEFAULT NULL,
  `buku_id` int(11) DEFAULT NULL,
  `qty` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman_detail` */

insert  into `peminjaman_detail`(`id`,`peminjaman_id`,`buku_id`,`qty`) values (1,1,4,'1'),(2,2,3,'1'),(3,3,5,'1'),(4,3,8,'1'),(5,4,7,'2'),(6,4,8,'1'),(7,5,4,'1'),(8,5,3,'1'),(9,5,7,'1'),(10,6,9,'1'),(11,7,5,'1'),(12,7,3,'1'),(13,8,9,'1'),(14,9,4,'1'),(15,10,5,'1'),(16,11,4,'1'),(17,11,3,'1'),(18,12,5,'1'),(19,13,4,'1'),(20,14,4,'1'),(21,15,4,'1'),(22,16,5,'1'),(23,16,9,'1'),(24,17,7,'1'),(25,18,8,'1'),(26,18,5,'1'),(27,18,9,'1'),(28,19,3,'1'),(29,20,7,'1');

/*Table structure for table `pengembalian` */

DROP TABLE IF EXISTS `pengembalian`;

CREATE TABLE `pengembalian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(11) DEFAULT NULL,
  `tgl_pengembalian` varchar(50) DEFAULT NULL,
  `denda` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `pengembalian` */

insert  into `pengembalian`(`id`,`peminjaman_id`,`tgl_pengembalian`,`denda`) values (1,2,'2026-02-25','0'),(2,4,'2026-04-01','0'),(3,8,'2026-04-25','50000'),(4,9,'2026-02-25','0'),(5,11,'2026-02-25',NULL),(6,13,'2026-02-25','30000'),(7,20,'2026-02-25',NULL);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','siswa') DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`nama`,`username`,`password`,`role`,`created_at`) values (1,'admin','admin','$2y$10$80HdD2tygk2S5uNaBJoR1OzdqwGuUJlTfFW6D998n/zuc3uGC7Ylm','admin',NULL),(5,'robin','robin','$2y$10$d6lrR/OBORI3I1UdDWUHweOlwYg7HjidEixglXRtdCJFEl7QqExqq','siswa',NULL),(4,'kairi','kairi','$2y$10$B1DjM3S1Vh0YSy6CmyD0eOBKLKNnwyhMc2PPWD1l.tb0uP4X0gtq2','siswa',NULL),(6,'adam','adam','$2y$10$PH7EsG7vLzDoYj8gY785YOl6K0F0TMi/RorEoS/E0fHXfMlqXbv6G','siswa',NULL),(7,'nana','nana','$2y$10$5eKeIF0syf2efqGhK1K1WOvpeDqpNSLTwg2MONmWUyfmp4TXJqB.a','siswa',NULL),(8,'tata','tata','$2y$10$0UGexkJalLbWDKaWd.rktu.d2W4VFYY4eurQpAiSyrTB0525WJsTS','siswa',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
