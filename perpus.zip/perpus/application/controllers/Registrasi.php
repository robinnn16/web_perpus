<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('anggota_model', 'mdl');
    }

    public function index()
    {
        $this->load->view('back-end/form/registrasi');
    }

    public function save()
    {
        // ================= VALIDASI MINIMAL =================
        if (
            !$this->input->post('username') ||
            !$this->input->post('password')
        ) {
            echo json_encode(['status' => false, 'msg' => 'Data tidak lengkap']);
            return;
        }

        $this->db->trans_start(); // 🔥 WAJIB

        // ================= INSERT USERS =================
        $dataUser = [
            'nama'     => $this->input->post('nm_siswa', true),
            'username' => $this->input->post('username', true),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'role'     => 'siswa'
        ];

        $this->db->insert('users', $dataUser);
        $id_user = $this->db->insert_id();

        // ================= INSERT ANGGOTA =================
        $dataAnggota = [
            'user_id' => $id_user,
            'nis'     => $this->input->post('nis', true),
            'kelas'   => $this->input->post('kelas', true),
            'alamat'  => $this->input->post('alamat', true),
            'status'  => 'aktif' // 🔥 INI PENTING
        ];

        $this->db->insert('anggota', $dataAnggota);

        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            echo json_encode(['status' => false]);
        } else {
            echo json_encode(['status' => true]);
        }
    }
}
