<section class="content">
    <div class="container-fluid">
        <div class="row">

            <!-- FORM -->
            <div class="col-md-4">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Form Buku</h3>
                    </div>

                    <form id="form-buku">
                        <div class="card-body">

                            <!-- PK -->
                            <input type="hidden" name="id" id="id">

                            <div class="form-group">
                                <label>Kode Buku</label>
                                <input type="text" name="kode_buku" id="kode_buku" class="form-control form-control-sm" required>
                            </div>

                            <div class="form-group">
                                <label>Judul</label>
                                <input type="text" name="judul" id="judul" class="form-control form-control-sm" required>
                            </div>

                            <div class="form-group">
                                <label>Pengarang</label>
                                <input type="text" name="pengarang" id="pengarang" class="form-control form-control-sm">
                            </div>

                            <div class="form-group">
                                <label>Penerbit</label>
                                <input type="text" name="penerbit" id="penerbit" class="form-control form-control-sm">
                            </div>

                            <div class="form-group">
                                <label>Tahun</label>
                                <input type="number" name="tahun" id="tahun" class="form-control form-control-sm">
                            </div>

                            <div class="form-group">
                                <label>Stok</label>
                                <input type="number" name="stok" id="stok" class="form-control form-control-sm">
                            </div>

                        </div>

                        <div class="card-footer text-right">
                            <button type="button" class="btn btn-sm btn-primary" id="btn-simpan">
                                <i class="fas fa-save"></i> Simpan
                            </button>

                            <button type="button" class="btn btn-sm btn-warning" id="btn-update" style="display:none;">
                                <i class="fas fa-edit"></i> Update
                            </button>

                            <button type="button" class="btn btn-sm btn-secondary" id="btn-refresh" style="display:none;">
                                Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- TABLE -->
            <div class="col-md-8">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Data Buku</h3>
                    </div>

                    <div class="card-body table-responsive">
                        <table id="table-buku" class="table table-bordered table-striped table-sm">
                            <thead class="text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Detail Buku</th>
                                    <th>Tahun</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $no = 1;
                                foreach ($result as $r): ?>
                                    <tr>
                                        <td class="text-center"><?= $no++ ?></td>
                                        <td>
                                            <b>Kode:</b> <?= $r->kode_buku ?><br>
                                            <b>Judul:</b> <?= $r->judul ?><br>
                                            <b>Pengarang:</b> <?= $r->pengarang ?><br>
                                            <b>Penerbit:</b> <?= $r->penerbit ?>
                                        </td>
                                        <td class="text-center"><?= $r->tahun ?></td>
                                        <td class="text-center"><?= $r->stok ?></td>
                                        <td class="text-center">
                                            <button class="btn btn-warning btn-sm" onclick="edit(<?= $r->id ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm" onclick="hapus(<?= $r->id ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<script>
    $(function() {

        $('#table-buku').DataTable({
            ordering: false
        });

        $('#btn-simpan').click(function() {
            $.ajax({
                url: "<?= site_url('back-end/Buku/save') ?>",
                type: "POST",
                data: $('#form-buku').serialize(),
                dataType: "json",
                success: function(res) {
                    if (res.status) {
                        location.reload();
                    }
                }
            });
        });

        $('#btn-update').click(function() {
            $.ajax({
                url: "<?= site_url('back-end/Buku/update') ?>",
                type: "POST",
                data: $('#form-buku').serialize(),
                dataType: "json",
                success: function(res) {
                    if (res.status) {
                        location.reload();
                    }
                }
            });
        });

        $('#btn-refresh').click(function() {
            location.reload();
        });
    });

    function edit(id) {
        $.getJSON("<?= site_url('back-end/Buku/edit/') ?>" + id, function(d) {
            $('#id').val(d.id);
            $('#kode_buku').val(d.kode_buku);
            $('#judul').val(d.judul);
            $('#pengarang').val(d.pengarang);
            $('#penerbit').val(d.penerbit);
            $('#tahun').val(d.tahun);
            $('#stok').val(d.stok);

            $('#btn-simpan').hide();
            $('#btn-update,#btn-refresh').show();
        });
    }

    function hapus(id) {
        if (confirm('Hapus data?')) {
            $.getJSON("<?= site_url('back-end/Buku/hapus/') ?>" + id, function() {
                location.reload();
            });
        }
    }
</script>