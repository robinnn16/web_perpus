<section class="content-header">
    <div class="container-fluid">

        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fa fa-book"></i> Riwayat Peminjaman Buku
                </h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="DataTables" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">No Peminjaman</th>
                                <th class="text-center">Detail Anggota</th>
                                <th class="text-center">Status</th>
                                <th class="text-center" style="width:15%">#</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($resultPeminjaman as $rs) {
                                echo '
                                 <tr>
                                    <td class="text-center">'.$no.'</td>
                                    <td class="text-center">
                                        '.$rs->id.'<br>
                                        Tgl Pinjam: '.date('d-m-Y', strtotime($rs->tgl_pinjam)).'<br>
                                        Tgl Kembali: '.date('d-m-Y', strtotime($rs->tgl_kembali)).'
                                    </td>
                                   <td>
                                        '.$rs->nis.'<br>
                                        Nama: '.$rs->nama.'<br>
                                        Kelas: '.$rs->kelas.'
                                    </td>
                                     <td class="text-center">
                                        <div id="status'.$rs->id.'">';
                                            if ($rs->status == "dikembalikan") {
                                                echo '<label class="badge badge-success">Dikembalikan</label>';
                                            } else {
                                                echo '<label class="badge badge-danger">Dipinjam</label>';
                                            }
                                echo '
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-primary"
                                            onclick="viewBuku(\''.$rs->id.'\')">
                                            <i class="fa fa-book"></i> Lihat Buku
                                        </button>
                                    </td>
                                </tr>';
                                $no++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- MODAL -->
<div class="modal fade" id="modalPengembalian">
    <div class="modal-dialog modal-lg" style="max-width:90%">
        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title">
                    <i class="fa fa-book"></i> RIWAYAT BUKU
                </h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-sm table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Detail Buku</th>
                                <th class="text-center">Qty</th>
                            </tr>
                        </thead>
                        <tbody id="viewListBuku"></tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    $('#DataTables').DataTable({
        paging: true,
        ordering: false,
        responsive: true,
        buttons: ["copy", "csv", "excel", "pdf", "print", "colvis"]
    });
});

function viewBuku(id) {
    $.ajax({
        type: "GET",
        url: "<?= site_url('back-end/riwayat/viewBuku/') ?>" + id,
        success: function (data) {
            $("#viewListBuku").html(data);
            $("#modalPengembalian").modal('show');
        }
    });
    return false;
}
</script>
