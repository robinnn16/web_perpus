<?php
$role = $this->session->userdata('role'); // admin / siswa
?>

<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="collapse navbar-collapse show">
                <ul class="navbar-nav flex-column">

                    <!-- DASHBOARD (SEMUA ROLE) -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('halaman-sistem') ?>">
                            <i class="fa fa-fw fa-home"></i> Dashboard
                        </a>
                    </li>

                    <?php if ($role === 'admin'): ?>
                        <!-- ================= ADMIN ================= -->

                        <!-- MASTER DATA -->
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-toggle="collapse"
                               data-target="#submenu-master">
                                <i class="fas fa-fw fa-database"></i> Master Data
                            </a>
                            <div id="submenu-master" class="collapse submenu">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= site_url('data-buku') ?>">Data Buku</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= site_url('data-anggota') ?>">Data Anggota</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <!-- TRANSAKSI ADMIN -->
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-toggle="collapse"
                               data-target="#submenu-transaksi">
                                <i class="fas fa-fw fa-exchange-alt"></i> Transaksi
                            </a>
                            <div id="submenu-transaksi" class="collapse submenu">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= site_url('data-riwayat') ?>">
                                            Riwayat Peminjaman
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= site_url('data-peminjaman') ?>">
                                            Data Peminjaman
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= site_url('data-pengembalian') ?>">
                                            Data Pengembalian
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                    <?php elseif ($role === 'siswa'): ?>
                        <!-- ================= SISWA ================= -->

                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('data-peminjaman') ?>">
                                <i class="fas fa-fw fa-book"></i> Peminjaman
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('data-pengembalian') ?>">
                                <i class="fas fa-fw fa-undo"></i> Pengembalian
                            </a>
                        </li>

                    <?php endif; ?>

                    <!-- LOGOUT -->
                    <li class="nav-divider mt-3">SETTING</li>
                    <li class="nav-item">
                        <a class="nav-link text-danger"
                           href="<?= site_url('logout-sistem') ?>"
                           onclick="return confirm('Yakin logout?')">
                            <i class="fas fa-fw fa-sign-out-alt"></i> Logout
                        </a>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>
