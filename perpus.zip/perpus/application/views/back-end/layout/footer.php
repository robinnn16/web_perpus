</div>
<!-- end main wrapper -->

<!-- BOOTSTRAP -->
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.js')?>"></script>

<!-- SLIMSCROLL -->
<script src="<?= base_url('assets/vendor/slimscroll/jquery.slimscroll.js')?>"></script>

<!-- MAIN JS -->
<script src="<?= base_url('assets/libs/js/main-js.js')?>"></script>

<!-- DATATABLES JS (SETELAH JQUERY) -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<!-- OPTIONAL (CHART, BOLEH ADA) -->
<script src="<?= base_url('assets/vendor/charts/chartist-bundle/chartist.min.js')?>"></script>
<script src="<?= base_url('assets/vendor/charts/sparkline/jquery.sparkline.js')?>"></script>
<script src="<?= base_url('assets/vendor/charts/morris-bundle/raphael.min.js')?>"></script>
<script src="<?= base_url('assets/vendor/charts/morris-bundle/morris.js')?>"></script>
<script src="<?= base_url('assets/vendor/charts/c3charts/d3-5.4.0.min.js')?>"></script>
<script src="<?= base_url('assets/vendor/charts/c3charts/c3.min.js')?>"></script>

</body>
</html>
